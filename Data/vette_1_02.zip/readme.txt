The included version of VETTE! asks for a password only once, upon first running the program.  The passwords can all be found in the first few pages of the file "Manual.pdf."
